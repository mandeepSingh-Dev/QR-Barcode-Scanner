package com.example.simpleqrbarcodescanner_noads.Util

object Intent_KEYS
{
    const val QRCODE = "qrCode"
    const val FORMAT = "format"
    const val VALUETYPE = "valuetype"
    const val BARCODE = "barcode"
     /* const val QRCODE = "qrCode"
    const val QRCODE = "qrCode"
    const val QRCODE = "qrCode"*/
}