package com.example.simpleqrbarcodescanner_noads

import android.content.Context
import android.view.SurfaceView


class ViewMy(context: Context):SurfaceView(context)
{

}