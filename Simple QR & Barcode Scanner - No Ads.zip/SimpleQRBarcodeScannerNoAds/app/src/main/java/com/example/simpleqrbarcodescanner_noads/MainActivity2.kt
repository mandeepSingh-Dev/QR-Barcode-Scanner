package com.example.simpleqrbarcodescanner_noads

import android.annotation.SuppressLint
import android.graphics.BitmapFactory
import android.graphics.ImageFormat
import android.graphics.Rect
import android.graphics.YuvImage
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Parcelable
import android.util.Log
import android.view.LayoutInflater
import android.view.Window
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.example.simpleqrbarcodescanner_noads.Util.Intent_KEYS
import com.example.simpleqrbarcodescanner_noads.databinding.ActivityMain2Binding
import com.example.simpleqrbarcodescanner_noads.databinding.ActivityMainBinding
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import java.io.ByteArrayOutputStream

 class MainActivity2 : AppCompatActivity()
{
     lateinit var binding:ActivityMain2Binding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMain2Binding.inflate(LayoutInflater.from(this))
        setContentView(binding.root)

        val qrCOde = intent.getStringExtra(Intent_KEYS.QRCODE)
        val format = intent.getIntExtra(Intent_KEYS.FORMAT, 0)
        val valueType = intent.getIntExtra(Intent_KEYS.VALUETYPE,0)


        when(valueType){
            Barcode.TYPE_URL ->{

            }
        }
        val bitmap = MainActivity().qrGenerate(qrCOde, format)
        binding.codeImage.setImageBitmap(bitmap)
        binding.result.text = qrCOde

    }

}